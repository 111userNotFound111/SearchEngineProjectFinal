# SearchEngineProjectFinal


To run the app : 
At Terminal : 

pip install .

myapp


